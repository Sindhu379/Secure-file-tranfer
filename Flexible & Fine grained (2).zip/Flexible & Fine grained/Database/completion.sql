/*
SQLyog Community Edition- MySQL GUI v6.56
MySQL - 5.5.30 : Database - completion
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`completion` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `completion`;

/*Table structure for table `downloads` */

DROP TABLE IF EXISTS `downloads`;

CREATE TABLE `downloads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `time` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `downloads` */

insert  into `downloads`(`id`,`filename`,`username`,`time`) values (2,'SMS.txt','sudip','2017/03/28 17:16:44');

/*Table structure for table `reg` */

DROP TABLE IF EXISTS `reg`;

CREATE TABLE `reg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `dob` varchar(45) NOT NULL,
  `gen` varchar(45) NOT NULL,
  `role` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `pkey` varchar(100) NOT NULL,
  `gpkey` varchar(45) NOT NULL,
  `pstatus` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `reg` */

insert  into `reg`(`id`,`name`,`pass`,`email`,`dob`,`gen`,`role`,`state`,`country`,`status`,`pkey`,`gpkey`,`pstatus`) values (3,'sudip','123','sudip@ibridge.co.in','2017-03-05','GroupA','User','KA','India','No','tuhpxFqOeVrnYR9UmYzv1Q==','6GZ9YNxbMPz0hGzf36TtPQ==','Yes'),(4,'Ram','123','sudip@ibridge.co.in','2017-03-05','GroupA','Owner','KA','India','No','tuhpxFqOeVrnYR9UmYzv1Q==','6GZ9YNxbMPz0hGzf36TtPQ==','Yes');

/*Table structure for table `request` */

DROP TABLE IF EXISTS `request`;

CREATE TABLE `request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `mail` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `fname` varchar(45) NOT NULL,
  `secretkey` longtext NOT NULL,
  `status` varchar(45) NOT NULL,
  `gpkey` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `request` */

insert  into `request`(`id`,`name`,`mail`,`state`,`country`,`fname`,`secretkey`,`status`,`gpkey`) values (2,'sudip','sudip@ibridge.co.in','KA','India','SMS.txt','i4OxCEzTQUB6w1ECwAZK+A==','Yes','6GZ9YNxbMPz0hGzf36TtPQ==');

/*Table structure for table `upload` */

DROP TABLE IF EXISTS `upload`;

CREATE TABLE `upload` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(45) NOT NULL,
  `content` longblob NOT NULL,
  `owner` varchar(45) NOT NULL,
  `time` varchar(45) NOT NULL,
  `gpkey` varchar(45) NOT NULL,
  `fileaccess` longtext NOT NULL,
  `ogroup` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `upload` */

insert  into `upload`(`id`,`filename`,`content`,`owner`,`time`,`gpkey`,`fileaccess`,`ogroup`) values (2,'SMS.txt','4CM6U/vBHCsphAMN7TR91oRb1skbs3cYQmEgEH63/6JU5nc+DOC2LSA+BG5zabU/Os4zzymDefUI\r\nZ2uph35zcnanjMwedtyEzOnJj8vrkfHddYOs4S7laB+MgU1NZ4OTstc9P/etgRLkobA4RXYwcGYX\r\nUzXLobyNeptoU9QexTY=','Ram','2017.03.28 AD at 17:10:17 ','6GZ9YNxbMPz0hGzf36TtPQ==','i4OxCEzTQUB6w1ECwAZK+A==','GroupA');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
